import { Controller, Get, Query } from "@nestjs/common";
import { AppService, ChainID } from "./app.service";
import { IsEthereumAddress, IsIn, IsNumberString } from "class-validator";
import axios from "axios";

const POLYGON_CHAIN_ID = '137';
const ARBITRUM_CHAIN_ID = '42161';

class GetSwapParamsQueryDto {
  @IsIn([POLYGON_CHAIN_ID, ARBITRUM_CHAIN_ID])
  fromChain: ChainID;

  @IsEthereumAddress()
  fromToken: string;

  @IsNumberString()
  fromAmount: number;

  @IsIn([POLYGON_CHAIN_ID, ARBITRUM_CHAIN_ID])
  toChain: ChainID;

  @IsEthereumAddress()
  toToken: string;
}

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Get('aaa')
  async getaaa(): Promise<string> {
    const routerCC = await this.appService.getCrossChainRouter(POLYGON_CHAIN_ID);
    console.log(await routerCC['getAssetData(uint256,uint256)'](ARBITRUM_CHAIN_ID, 2));
    return 'ok';
  }

  @Get('swapParams')
  async getSwapParams(
    @Query()
    {
      fromChain,
      fromToken,
      fromAmount,
      toChain,
      toToken,
    }: GetSwapParamsQueryDto,
  ): Promise<object> {
    const pool = await this.appService.getPoolContract(fromChain);
    const poolCC = await this.appService.getCrossChainPoolContract(fromChain);
    const routerCC = await this.appService.getCrossChainRouter(fromChain);
    const swapRouter = await this.appService.getSwapRouter(fromChain);
    const { lowestAsset: lwsAssetAddress, highestAsset: hgsAssetAddress } =
      await pool.getHighestAndLowestCompRatioAssets();
    const lwsAsset = await this.appService.getAssetContract(
      fromChain,
      lwsAssetAddress,
    );
    const lwsTokenAddress = await lwsAsset.underlyingToken();
    const hgsAsset = await this.appService.getAssetContract(
      fromChain,
      hgsAssetAddress,
    );
    const hgsTokenAddress = await hgsAsset.underlyingToken();
    const hgsAssetId = (
      await routerCC['getAssetData(uint256,address)'](
        fromChain,
        hgsAssetAddress,
      )
    ).assetId;
    let hgsTokenAddressDest = (
      await routerCC['getAssetData(uint256,uint256)'](toChain, hgsAssetId)
    ).nativeTokenAddress;
    if (hgsTokenAddressDest === '0x54Ee6EC91B990284B811d1eb20e3637ba30f1efb') {
      hgsTokenAddressDest = '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9';
    }
    const { data } = await axios.get(
      `https://api.1inch.io/v4.0/${fromChain}/swap`,
      {
        params: {
          fromTokenAddress: fromToken,
          toTokenAddress: lwsTokenAddress,
          amount: fromAmount,
          fromAddress: swapRouter.address,
          slippage: '1',
          disableEstimate: true,
        },
      },
    );
    console.log(data.tx);
    // pool.swapCrossChain(fromToken, fromAmount, minimumToAmount, dstAssetId, dstChain, deadline, executionFee);
    const swapData = swapRouter.interface.encodeFunctionData(
      swapRouter.interface.functions[
        'startSwap((address,uint256,address,address,bytes,address,uint256,address,uint256))'
      ],
      [
        [
          fromToken,
          fromAmount,
          lwsTokenAddress,
          data.tx.to,
          data.tx.data,
          hgsTokenAddressDest,
          hgsAssetId,
          toToken,
          toChain,
        ],
      ],
    );
    const value = (await swapRouter.estimateFee()).toString();
    return {
      data: swapData,
      to: swapRouter.address,
      value,
    };
    // return { fromChain, fromToken, fromAmount, toChain, toToken };
  }
}
